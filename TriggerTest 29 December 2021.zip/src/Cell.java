import javafx.beans.binding.Bindings;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.ListCell;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class Cell extends ListCell<Person> {
    @Override
    protected void updateItem(Person item, boolean empty) {
        super.updateItem(item, empty);
        if(item == null || empty){
            setText(null);
            setGraphic(null);
        }else{
            setPrefWidth(0);
            var name = new Text();
            var age = new Text();
            var isMale = new Text();
            var box = new HBox(name, age, isMale);

            name.textProperty().bind(item.nameProperty());
            age.textProperty().bind(Bindings.convert(item.ageProperty()));
            isMale.textProperty().bind(Bindings.convert(item.isMaleProperty()));

            if (item.getAge() < 40) {
                name.setFill(Color.GREEN);
                age.setFill(Color.GREEN);
                isMale.setFill(Color.GREEN);
            } else {
                name.setFill(Color.BLACK);
                age.setFill(Color.BLACK);
                isMale.setFill(Color.BLACK);
            }

            if(isSelected()){
                name.setFont(Font.font(null, FontWeight.BOLD, -1));
                age.setFont(Font.font(null, FontWeight.BOLD, -1));
                isMale.setFont(Font.font(null, FontWeight.BOLD, -1));

                name.setFill(Color.WHITE);
                age.setFill(Color.WHITE);
                isMale.setFill(Color.WHITE);

                setBackground(new Background(new BackgroundFill(Color.CORAL, new CornerRadii(10), null)));
            }
            else{
                setBackground(null);
                if(item.isMale())
                    box.setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, new CornerRadii(10), null)));
            }

            box.setSpacing(10);
            setText(null);
            setGraphic(box);
        }
    }
}

import javafx.beans.binding.Bindings;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

import java.util.concurrent.Callable;

public class EditableCell extends ListCell<Person> {
    ContextMenu menu;
    boolean isOnEdit;

    public EditableCell() {
        menu = new ContextMenu();
        var edit = new MenuItem("Edit");
        var delete = new MenuItem("Delete");
        menu.getItems().addAll(edit, delete);
        delete.setOnAction(e -> {
            getListView().getItems().remove(getIndex());
        });
        edit.setOnAction(e -> startEdit());
    }

    void setNonEditable() {
        var name = new Text();
        var age = new Text();
        var isMale = new Text();
        var edit = new Button("/");
        var delete = new Button("X");
        var buttons = new HBox(edit, delete);
        var box = new HBox(name, age, isMale, buttons);
        buttons.setAlignment(Pos.BOTTOM_RIGHT);
        HBox.setHgrow(buttons, Priority.ALWAYS);
        edit.setTooltip(new Tooltip("edit"));
        delete.setTooltip(new Tooltip("delete"));
        box.setAlignment(Pos.CENTER);

        edit.setOnAction(e -> startEdit());
        delete.setOnAction(e -> getListView().getItems().remove(getIndex()));

        var item = getItem();
        name.textProperty().bind(item.nameProperty());
        age.textProperty().bind(Bindings.convert(item.ageProperty()));
        isMale.textProperty().bind(Bindings.convert(item.isMaleProperty()));

        if (item.getAge() < 40) {
            name.setFill(Color.GREEN);
            age.setFill(Color.GREEN);
            isMale.setFill(Color.GREEN);
        } else {
            name.setFill(Color.BLACK);
            age.setFill(Color.BLACK);
            isMale.setFill(Color.BLACK);
        }

        if (isSelected()) {
            name.setFont(Font.font(null, FontWeight.BOLD, -1));
            age.setFont(Font.font(null, FontWeight.BOLD, -1));
            isMale.setFont(Font.font(null, FontWeight.BOLD, -1));

            name.setFill(Color.WHITE);
            age.setFill(Color.WHITE);
            isMale.setFill(Color.WHITE);
            setBackground(new Background(new BackgroundFill(Color.CORAL, new CornerRadii(10), null)));
        } else {
            setBackground(null);
            if (item.isMale())
                box.setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, new CornerRadii(10), null)));
        }

        box.setSpacing(10);
        setGraphic(box);
        setContextMenu(menu);
    }

    void setEditable() {
        var item = getItem();
        var name = new TextField(item.getName());
        var age = new TextField(String.valueOf(item.getAge()));
        var isMale = new CheckBox("is Male");
        isMale.setSelected(item.isMale());
        HBox.setHgrow(isMale, Priority.ALWAYS);
        var box = new HBox(name, age, isMale);

        box.setSpacing(10);
        box.setAlignment(Pos.CENTER);
        item.nameProperty().bind(name.textProperty());
        item.ageProperty().bind(Bindings.createIntegerBinding(new Callable<Integer>() {
            @Override
            public Integer call() throws Exception {
                return age.getText().isEmpty() ? 0 : Integer.parseInt(age.getText());
            }
        }, age.textProperty()));

        item.isMaleProperty().bind(isMale.selectedProperty());

        name.setOnKeyReleased(this::setCommit);
        age.setOnKeyReleased(this::setCommit);

        setGraphic(box);
        setContextMenu(null);
        setBackground(null);
        name.positionCaret(name.getLength());
        name.requestFocus();
    }

    void setCommit(KeyEvent e) {
        if (e.getCode() == KeyCode.ENTER) cancelEdit();
        else if (e.getCode() == KeyCode.ESCAPE) cancelEdit();
    }

    @Override
    public void startEdit() {
        super.startEdit();
        setEditable();
        isOnEdit = true;
    }
    @Override
    public void cancelEdit() {
        super.cancelEdit();
        isOnEdit = false;
        setNonEditable();
    }
    @Override
    protected void updateItem(Person item, boolean empty) {
        super.updateItem(item, empty);
        if (item == null || empty) {
            setText(null);
            setGraphic(null);
            setContextMenu(null);
        } else {
            setPrefWidth(0);
            setText(null);
            if (!isOnEdit) setNonEditable();
        }
    }
}

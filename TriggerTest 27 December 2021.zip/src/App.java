import javafx.application.Application;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.StringConverter;

public class App extends Application {
    ObservableList<Person> people;
    FilteredList<Person> maleOnly, femaleOnly, lessThan40, fortyPlus;
    ListView<Person> maleOnlyView, femaleOnlyView, lessThan40View, fortyPlusView, allView;
    VBox maleOnlyBox, femaleOnlyBox, lessThan40Box, fortyPlusBox, allBox, editBox;
    ObjectProperty<Person> selectedPerson;

    @Override
    public void start(Stage stage) {
        addPeople();
        initLists();
        initBoxes();

        var row1 = new RowConstraints();
        var row2 = new RowConstraints();
        row1.setPercentHeight(50);
        row2.setPercentHeight(50);

        var col1 = new ColumnConstraints();
        var col2 = new ColumnConstraints();
        var col3 = new ColumnConstraints();
        col1.setPercentWidth(33.33);
        col2.setPercentWidth(33.33);
        col3.setPercentWidth(33.33);

        var grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(10));
        grid.getColumnConstraints().addAll(col1, col2, col3);
        grid.getRowConstraints().addAll(row1, row2);
        grid.addRow(0, maleOnlyBox, femaleOnlyBox, allBox);
        grid.addRow(1, lessThan40Box, fortyPlusBox, editBox);

        stage.setTitle("Trigger & Live Filter Test");
        stage.setScene(new Scene(grid, 800,600));
        stage.show();
    }

    void initBoxes() {
        maleOnlyBox = new VBox(new Text("Male only"), maleOnlyView);
        femaleOnlyBox = new VBox(new Text("Female only"), femaleOnlyView);
        lessThan40Box = new VBox(new Text("Less than 40"), lessThan40View);
        fortyPlusBox = new VBox(new Text("Forty and above"), fortyPlusView);
        allBox = new VBox(new Text("All"), allView);

        initEditBoxes();
    }
    void initEditBoxes() {
        var header = new Text("Update");
        var name = new TextField();
        var age = new TextField();
        var isMale = new CheckBox();
        var save = new Button("save");

        name.setPromptText("Name");
        age.setPromptText("Age");
        isMale.setText("is Male");

        editBox = new VBox(header, name, age, isMale, save);
        editBox.setSpacing(10);

        selectedPerson.addListener((observable, oldValue, newValue) -> {
            if(oldValue != null){
                name.textProperty().unbindBidirectional(oldValue.nameProperty());
                age.textProperty().unbindBidirectional(oldValue.ageProperty());
                isMale.selectedProperty().unbindBidirectional(oldValue.isMaleProperty());
            }
            if(newValue != null){
                name.textProperty().bindBidirectional(newValue.nameProperty());
                isMale.selectedProperty().bindBidirectional(newValue.isMaleProperty());
                Bindings.bindBidirectional(age.textProperty(), newValue.ageProperty(), new StringConverter<Number>() {
                    @Override
                    public String toString(Number object) {
                        return String.valueOf(object);
                    }

                    @Override
                    public Number fromString(String string) {
                        return string.isEmpty() ? 0 : Integer.parseInt(string);
                    }
                });
            }
        });


        save.disableProperty().bind(name.textProperty().isEmpty().or(age.textProperty().isEmpty()));
        save.setOnAction(e ->{
            var person = people.get(people.indexOf(selectedPerson.get()));
            person.setName(name.getText());
            person.setAge(Integer.parseInt(age.getText()));
            person.setMale(isMale.isSelected());
        });
    }
    void initLists(){
        maleOnly = new FilteredList<>(people, Person::isMale);
        femaleOnly = new FilteredList<>(people, p -> !p.isMale());
        lessThan40 = new FilteredList<>(people, p -> p.getAge() < 40);
        fortyPlus = new FilteredList<>(people, p -> p.getAge() >= 40);

        maleOnlyView = new ListView<>(maleOnly);
        femaleOnlyView = new ListView<>(femaleOnly);
        lessThan40View = new ListView<>(lessThan40);
        fortyPlusView = new ListView<>(fortyPlus);
        allView = new ListView<>(people);

        maleOnlyView.setCellFactory(v -> new Cell());
        femaleOnlyView.setCellFactory(v -> new Cell());
        fortyPlusView.setCellFactory(v -> new Cell());
        lessThan40View.setCellFactory(v -> new Cell());
        allView.setCellFactory(v -> new Cell());

        selectedPerson = new SimpleObjectProperty<>();
        selectedPerson.bind(allView.getSelectionModel().selectedItemProperty());
        allView.getSelectionModel().selectFirst();

    }
    void addPeople() {
        people = FXCollections.observableArrayList(p ->
            new Observable[]{
                p.isMaleProperty(),
                p.ageProperty()
        });
        people.add(new Person("Emon", 40, true));
        people.add(new Person("Haque", 45, true));
        people.add(new Person("Akm", 30, true));
        people.add(new Person("Abul", 20, true));
        people.add(new Person("Kashem", 50, true));
        people.add(new Person("Muhammad", 49, true));
        people.add(new Person("Monirul", 35, true));
        people.add(new Person("A female", 30, false));
        people.add(new Person("Another female", 40, false));
        people.add(new Person("More female", 45, false));
    }

    public static void main(String[] args) {
        launch(args);
    }
}

import javafx.beans.property.*;

public class Person {
    private StringProperty name;
    private IntegerProperty age;
    private BooleanProperty isMale;

    public Person(String name, int age, boolean isMale) {
        this.name = new SimpleStringProperty(name);
        this.age = new SimpleIntegerProperty(age);
        this.isMale = new SimpleBooleanProperty(isMale);
    }
    public StringProperty nameProperty() { return name; }
    public IntegerProperty ageProperty() { return age; }
    public BooleanProperty isMaleProperty() { return isMale; }

    public String getName() { return name.get(); }
    public void setName(String name) { this.name.set(name); }
    public int getAge() {
        return age.get();
    }
    public void setAge(int age) { this.age.set(age); }
    public boolean isMale() {
        return isMale.get();
    }
    public void setMale(boolean male) { this.isMale.set(male); }
}

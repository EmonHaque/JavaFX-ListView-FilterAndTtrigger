import javafx.application.Application;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.Event;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.StringConverter;

import java.util.Comparator;
import java.util.function.Function;
import java.util.function.ToIntFunction;

public class App extends Application {
    ObservableList<Person> people;
    FilteredList<Person> maleOnly, femaleOnly, lessThan40, fortyPlus;
    ListView<Person> maleOnlyView, femaleOnlyView, lessThan40View, fortyPlusView, allView;
    VBox maleOnlyBox, femaleOnlyBox, lessThan40Box, fortyPlusBox, allBox, editBox, addBox;
    ObjectProperty<Person> selectedPerson;

    @Override
    public void start(Stage stage) {
        addPeople();
        initLists();
        initBoxes();

        var row1 = new RowConstraints();
        var row2 = new RowConstraints();
        row1.setPercentHeight(50);
        row2.setPercentHeight(50);

        var col1 = new ColumnConstraints();
        var col2 = new ColumnConstraints();
        var col3 = new ColumnConstraints();
        col1.setPercentWidth(33.33);
        col2.setPercentWidth(33.33);
        col3.setPercentWidth(33.33);

        var grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(10));
        grid.getColumnConstraints().addAll(col1, col2, col3);
        grid.getRowConstraints().addAll(row1, row2);
        grid.addRow(0, maleOnlyBox, femaleOnlyBox, allBox);

        var addEditBoxes = new VBox(editBox, new Separator(), addBox);
        addEditBoxes.setSpacing(10);
        grid.addRow(1, lessThan40Box, fortyPlusBox, addEditBoxes);

        stage.setTitle("Trigger & Live Filter Test");
        stage.setScene(new Scene(grid, 800,600));
        stage.show();
    }

    void initBoxes() {
        maleOnlyBox = new VBox(new Text("Male only (Ascending Name, Age)"), maleOnlyView);
        femaleOnlyBox = new VBox(new Text("Female only"), femaleOnlyView);
        lessThan40Box = new VBox(new Text("Less than 40 (Descending Name)"), lessThan40View);
        fortyPlusBox = new VBox(new Text("Forty and above"), fortyPlusView);
        allBox = new VBox(new Text("All"), allView);

        initEditBoxes();
    }
    void initEditBoxes() {
        var editHeader = new Text("Update");
        var editName = new TextField();
        var editAge = new TextField();
        var editIsMale = new CheckBox();

        editName.setPromptText("Name");
        editAge.setPromptText("Age");
        editIsMale.setText("is Male");

        editBox = new VBox(editHeader, editName, editAge, editIsMale);
        editBox.setSpacing(10);

        selectedPerson.addListener((observable, oldValue, newValue) -> {
            if(oldValue != null){
                editName.textProperty().unbindBidirectional(oldValue.nameProperty());
                editAge.textProperty().unbindBidirectional(oldValue.ageProperty());
                editIsMale.selectedProperty().unbindBidirectional(oldValue.isMaleProperty());
            }
            if(newValue != null){
                editName.textProperty().bindBidirectional(newValue.nameProperty());
                editIsMale.selectedProperty().bindBidirectional(newValue.isMaleProperty());
                Bindings.bindBidirectional(editAge.textProperty(), newValue.ageProperty(), new StringConverter<Number>() {
                    @Override
                    public String toString(Number object) {
                        return String.valueOf(object);
                    }

                    @Override
                    public Number fromString(String string) {
                        return string.isEmpty() ? 0 : Integer.parseInt(string);
                    }
                });
            }
        });

        var addHeader = new Text("Add");
        var addName = new TextField();
        var addAge = new TextField();
        var addIsMale = new CheckBox();
        var add = new Button("add");

        addName.setPromptText("Name");
        addAge.setPromptText("Age");
        addIsMale.setText("is Male");

        addBox = new VBox(addHeader, addName, addAge, addIsMale, add);
        addBox.setSpacing(10);

        add.disableProperty().bind(addName.textProperty().isEmpty().or(addAge.textProperty().isEmpty()));
        add.setOnAction(e ->{
            var person = new Person(addName.getText(), Integer.parseInt(addAge.getText()), addIsMale.isSelected());
            people.add(person);
            addName.setText("");
            addAge.setText("");
            addIsMale.setSelected(false);
        });
    }
    void initLists(){
        var nameAscending = Comparator.comparing(Person::getName).thenComparing(Person::getAge);
        var nameDescending = new Comparator<Person>(){
            @Override
            public int compare(Person o1, Person o2) {
                return o2.getName().compareToIgnoreCase(o1.getName());
            }
        };
        maleOnly = new FilteredList<>(people.sorted(nameAscending), Person::isMale);
        femaleOnly = new FilteredList<>(people, p -> !p.isMale());
        lessThan40 = new FilteredList<>(people.sorted(nameDescending), p -> p.getAge() < 40);
        fortyPlus = new FilteredList<>(people, p -> p.getAge() >= 40);

        maleOnlyView = new ListView<>(maleOnly);
        femaleOnlyView = new ListView<>(femaleOnly);
        lessThan40View = new ListView<>(lessThan40);
        fortyPlusView = new ListView<>(fortyPlus);
        allView = new ListView<>(people);

        maleOnlyView.setBackground(null);
        femaleOnlyView.setBackground(null);
        lessThan40View.setBackground(null);
        fortyPlusView.setBackground(null);
        allView.setBackground(null);

        var border = new Border(new BorderStroke(Color.CORNFLOWERBLUE, Color.TRANSPARENT, Color.CORNFLOWERBLUE, null, BorderStrokeStyle.SOLID, null, BorderStrokeStyle.SOLID, null, null, BorderWidths.DEFAULT, null));
        maleOnlyView.setBorder(border);
        femaleOnlyView.setBorder(border);
        lessThan40View.setBorder(border);
        fortyPlusView.setBorder(border);
        allView.setBorder(border);

        maleOnlyView.setCellFactory(v -> new Cell());
        femaleOnlyView.setCellFactory(v -> new Cell());
        fortyPlusView.setCellFactory(v -> new Cell());
        lessThan40View.setCellFactory(v -> new Cell());
        allView.setCellFactory(v -> new EditableCell());
        //allView.setEditable(true);
        //allView.addEventFilter(MouseEvent.MOUSE_PRESSED, Event::consume);
        //allView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

        selectedPerson = new SimpleObjectProperty<>();
        selectedPerson.bind(allView.getSelectionModel().selectedItemProperty());
        //allView.getSelectionModel().selectFirst();
    }
    void addPeople() {
        people = FXCollections.observableArrayList(p ->
            new Observable[]{
                p.nameProperty(),
                p.isMaleProperty(),
                p.ageProperty()
        });
        people.add(new Person("Emon", 40, true));
        people.add(new Person("Haque", 45, true));
        people.add(new Person("Akm", 30, true));
        people.add(new Person("Abul", 20, true));
        people.add(new Person("Kashem", 50, true));
        people.add(new Person("Muhammad", 49, true));
        people.add(new Person("Monirul", 35, true));
        people.add(new Person("A female", 30, false));
        people.add(new Person("Another female", 40, false));
        people.add(new Person("More female", 45, false));
    }

    public static void main(String[] args) {
        launch(args);
    }
}
